#include "iostream"

int main( int argc, char* args[] )
{
    std::cout << "What up world";
}
